DROP TABLE "Lessons";

DROP TABLE "Courses";

DROP DATABASE "node-typescript-rest-api";